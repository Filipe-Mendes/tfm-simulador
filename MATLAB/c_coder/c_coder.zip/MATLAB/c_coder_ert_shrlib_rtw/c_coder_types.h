/*
 * File: c_coder_types.h
 *
 * Code generated for Simulink model 'c_coder'.
 *
 * Model version                  : 8.153
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Tue Jul 23 17:45:33 2024
 *
 * Target selection: ert_shrlib.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_c_coder_types_h_
#define RTW_HEADER_c_coder_types_h_

/* Model Code Variants */

/* Forward declaration for rtModel */
typedef struct tag_RTM_c_coder_T RT_MODEL_c_coder_T;

#endif                                 /* RTW_HEADER_c_coder_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
